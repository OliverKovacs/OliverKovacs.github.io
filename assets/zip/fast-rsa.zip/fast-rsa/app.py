from Cryptodome.Util import number
import random
import math
import os

FLAG = os.environ.get('FLAG', 'dach2025{fake_flag}')

messages_good = [" is a cool number", " is really quite something", " likes to save me money"]
messages_bad = [" is ok I guess", " rubs me the wrong way sometimes", " is pretty expensive"]

class Montgomery:	
    def __init__(self, n):
        self.N = n

        self.nbits = self.N.bit_length()
        self.r = 1 << self.nbits

        self.nprime = pow(self.r, -1, self.N)
        self.factor = (self.r * self.nprime - 1) // self.N

    def convert_into_montgomery(self, x):
        return (x << self.nbits) % self.N

    def convert_from_montgomery(self, x):
        return (x * self.nprime) % self.N

    def multiply(self, x, y):
        product = x * y
        m = ((product % self.r) * self.factor) % self.r
        reduced = (product + m * self.N) >> self.nbits # the same as dividing by self.r
        if reduced < self.N:
            return reduced, False
        else:
            return reduced - self.N, True
	
    def pow(self, x, y, bit):
        if y < 0:
            raise ValueError("Negative exponent")
        z = self.convert_into_montgomery(1)
        price = 0
        bit_pos = self.nbits - 1
        expensive = False
        while bit_pos >= 0:
            z, extra_subtraction = self.multiply(z, z)
            if extra_subtraction:
                if bit_pos == bit:
                    expensive = True
                price += 1
            if (y & (1 << bit_pos)) != 0:
                z, extra_subtraction = self.multiply(z, x)
                if extra_subtraction:
                    if bit_pos == bit:
                        expensive = True
                    price += 1
            bit_pos -= 1
        return z, price, expensive
        
    def montgomery_pow(self, x, y, bit):
        x = self.convert_into_montgomery(x)
        z, price, expensive = self.pow(x, y, bit)
        return self.convert_from_montgomery(z), price, expensive

e = 0x10001

p, q = number.getPrime(1024), number.getPrime(1024)
phi = (p-1) * (q-1)
g = math.gcd(phi, e)

while g != 1:
    p, q = number.getPrime(1024), number.getPrime(1024)
    phi = (p-1) * (q-1)
    g = math.gcd(phi, e)
    
n = p * q
d = pow(e, -1, phi)

reducer = Montgomery(n)

ncredits = 10_000_000

print("Hey, I used a super fast Militech hardware encryption chip to create this message signature bot, but since I figured out that the Subtractions it performs are super expensive, I can only allow you a limited number of them so you don't destroy my bank account :D")
print("")
print("==============================")
print("Here is my public key for verification")
print()
print(f"n={hex(n)}")
print(f"e={hex(e)}")
print("==============================")
print("And just like how you can see the last 4 digits of your credit card on some websites for verification, I'll show you the first 4 bytes of d, so you can bring it back to me if I ever lose it.")
print()
print(f"top 4 bytes of d: {hex(d >> 2016)}")
print("==============================")

while ncredits > 0:
    print(f"You have {ncredits} credits left.")
    inp1 = input("please give me a message to sign (in hex), or nothing if you want to attempt my challenge: ").strip()
    if len(inp1) == 0:
        break
    try:
        inp1 = int(inp1, base=16)
    except ValueError:
        print("Invalid hexadecimal number, try again!")
        continue
    inp2 = input("to personalize your signature a little bit, what is your favourite number: ").strip()
    try:
        inp2 = int(inp2, base=0)
    except:
        inp2 = number.getRandomRange(0, reducer.nbits)
        print(f"Ok, then, using my favourite number {inp2} instead...")
        
    res, cost, expensive = reducer.montgomery_pow(inp1, d, inp2)
    if expensive:
        print(f"Message: {inp2}{random.choice(messages_bad)}")
    else:
        print(f"Message: {inp2}{random.choice(messages_good)}")
    print(f"Signature: {hex(res)}")
    ncredits -= cost

if ncredits <= 0:
    print(f"You are broke (and actually have {ncredits} credits left, but I'll give you a shot at my challenge anyways)")

chall = number.getRandomNBitInteger(256)
print(f"OK, please sign this message: {hex(chall)}")

sig = inp = int(input("Signature: ").strip(), base=16)
tgt, _, _ = reducer.montgomery_pow(chall, d, 0)

if sig == tgt:
    print(f"Wow, you did it, here is your reward: {FLAG}")
else:
    print("nope...")